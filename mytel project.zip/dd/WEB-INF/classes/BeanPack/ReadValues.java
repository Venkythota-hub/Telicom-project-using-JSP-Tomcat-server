package BeanPack;
import java.sql.*;
public class ReadValues
{
private String name;
private String nn;
private String pp;
private String add;
private String hh;

PreparedStatement st;
Connection con;
public ReadValues()
{
try{
Class.forName("com.mysql.jdbc.Driver");
System.out.println("driver loaded and registered");
con=DriverManager.getConnection("jdbc:mysql://localhost/venky469","root","Venky@12345");
System.out.println("connection is established");
}
catch(Exception ee)
{System.out.println(ee);}
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return name;
}
public void setNn(String nn)
{
this.nn=nn;
}
public String getNn()
{
return nn;
}
public void setPp(String pp)
{
this.pp=pp;
}
public String getPp()
{
return pp;
}
public void setAdd(String add)
{
this.add=add;
}
public String getAdd()
{
return add;
}
public void setHh(String hh)
{
this.hh=hh;
}
public String getHh()
{
return hh;
}

public void insert()
{
try{
st=con.prepareCall("insert into login values(?,?,?,?,?)");
st.setString(1,name);
st.setString(2,nn);
st.setString(3,pp);
st.setString(4,add);
st.setString(5,hh);
st.execute();
st.close();
con.close();
}catch(Exception ee)
{
System.out.println(ee);
}
}
}